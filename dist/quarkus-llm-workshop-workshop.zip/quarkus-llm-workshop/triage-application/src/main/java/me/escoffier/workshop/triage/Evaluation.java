package me.escoffier.workshop.triage;

public enum Evaluation {

    POSITIVE,
    NEGATIVE
}
